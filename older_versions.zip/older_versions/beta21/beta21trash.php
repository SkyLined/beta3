<?php
	// SETTINGS
	$max_input_data_length = 4000;
	$input_data_format = "/^(?i:[0-9A-F]{2})*$/";
?><HTML>
	<HEAD>
		<STYLE>
			* {
				font-family: Courier New;
				font-size: 10pt;
				vertical-align: middle;
				margin: 0px;
				padding: 0px;
				xtext-align: left;

			}
			TD, TR {
				vertical-align: top;
			}
			BODY {
				background: #808080;
			}
			.right_align {
				margin: 0px;
				padding: 0px;
				text-align: right;
				width: 100%;
				border: 0px solid black;
			}
			.layer1 {
				margin: 3px;
				padding: 3px;
				background: #C0C0C0;
				border: 2px outset #E0E0E0;
				width: 100%;
			}
			.logo {
				margin: 3px;
				padding: 3px;
				background:transparent;
				border: none;
				width:100%;
			}
			.layer2 {
				margin: 3px;
				padding: 6px;
				padding-top: 6px;
				padding-bottom: 6px;
				background: #E0E0E0;
				border: 2px outset #FFFFFF; 
				width: 100%;
			}
			.layer2_button {
				margin: 3px;
				padding: 3px;
				background: #E0E0E0;
				border: 2px outset #FFFFFF; 
			}
			.header {
				margin-bottom: 3px;
				padding: 3px;
				background: #C0C0C0;
				border: 1px solid #808080;
				width: 100%;
			}
			.body {
				margin-bottom: 3px;
				padding: 6px;
				border: 1px solid #808080;
				width: 100%;
			}	
			.note {
				margin-bottom: 3px;
				padding: 3px;
				background: #F0F0F0;
				border: 1px solid #D0D0D0;
				width:100%;
			}
			.error {
				margin-bottom: 3px;
				padding: 3px;
				background: #FFF0F0;
				border: 1px solid #E0D0D0;
				width:100%;
			}
			.input {
				xmargin-bottom: 3px;
				padding: 3px;
				background: #F0F0F0;
				border: 2px inset #FFFFFF; 
				width:100%;
				text-align: left;
			}
			.input_small {
				xmargin-bottom: 3px;
				padding: 3px;
				background: #F0F0F0;
				border: 2px inset #FFFFFF; 
				text-align: left;
			}
			.input_button {
				xmargin-bottom: 3px;
				padding: 3px;
				background: #F0F0F0;
				border: 2px inset #FFFFFF; 
				width: 100%;
				text-align: left;
			}
		</STYLE>
	</HEAD>
	<BODY><FORM enctype="multipart/form-data" action="?" method="POST">
		<DIV class="layer1">
			<BUTTON disabled class="logo">
				<TABLE cellpadding=0 cellspacing=0 style="width:100%">
					<TR><TD colspan="3"><HR></TD></TR>
					<TR><TD>&nbsp;&nbsp;</TD><TD>&nbsp;&nbsp;&nbsp;</TD><TD>,sSSSis&nbsp;&nbsp;&nbsp;,sSSSs,&nbsp;&nbsp;&nbsp;Beta&nbsp;v2.0.</TD></TR>
					<TR><TD>&nbsp;&nbsp;</TD><TD>&nbsp;&nbsp;i</TD><TD>S&quot;&nbsp;&nbsp;&nbsp;dP&nbsp;&nbsp;dY&quot;&nbsp;&nbsp;,SP&nbsp;&nbsp;&nbsp;Encodes&nbsp;binary&nbsp;data&nbsp;to&nbsp;a&nbsp;variety&nbsp;of&nbsp;formats.</TD></TR>
					<TR><TD>&nbsp;&nbsp;</TD><TD>&nbsp;.S</TD><TD>P&nbsp;dSS&quot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;,sS&quot;&nbsp;&nbsp;&nbsp;&nbsp;Copyright&nbsp;(C)&nbsp;2003-2005&nbsp;by&nbsp;Berend-Jan&nbsp;Wever</TD></TR>
					<TR><TD>&nbsp;&nbsp;</TD><TD>&nbsp;dS</TD><TD>'&nbsp;&nbsp;&nbsp;Sb&nbsp;&nbsp;&nbsp;&nbsp;,sY&quot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;skylined@edup.tudelft.nl&gt;</TD></TR>
					<TR><TD>&nbsp;&nbsp;</TD><TD>.SP</TD><TD>&nbsp;dSSP'&nbsp;&nbsp;sSSSSSSP&nbsp;&nbsp;&nbsp;&nbsp;http://spaces.msn.com/members/berendjanwever</TD></TR>
					<TR><TD><HR></TD><TD>iS:</TD><TD style="width: 100%"><HR></TD></TR>
				</TABLE>
			</BUTTON><?php
	if ($_POST && $_FILES['uploadfile']['tmp_name']) {
		//---------------------------------------------------------------------
		// THE USER HAS UPLOAD A FILE, ENCODE IT
		$use_marker = $_POST['use_marker'];
		$marker = $_POST['marker'];
		$marker_error = "";
  		$marker_start = -1;
  		$marker_end = -1;

		$use_badbytes = $_POST['use_badbytes'];
		$badbytes = $_POST['badbytes'];

		$filename = $_FILES['uploadfile']['name'];
		$filesize = intval($_FILES['uploadfile']['size']);
		$file = fopen($_FILES['uploadfile']['tmp_name'], 'r');
		$filecontents = fread($file, $max_input_data_length);
		fclose($file);
		$hex = "0123456789ABCDEF";
			for ($i = 0; $i < strlen($filecontents); $i++) {
		    	$char = ord($filecontents{$i});
		    	$input_data .= $hex{($char >> 4) & 0xF}.
		    	               $hex{$char & 0xF};
		  	}
		  	if ($use_marker) {
		  		$marker_hex = strtoupper(preg_replace("/[\s,]/i", "", $marker));
		  		if (preg_replace("/[0-9A-F]/i", "", $marker_hex)) {
		  			$marker_error = "Marker contains bad characters, whole file used.";
		  		} else {
			  		for ($i = 0; $marker_end < 0 && $i < strlen($input_data); $i+=2) {
			  			if (substr($input_data, $i, strlen($marker_hex)) == $marker_hex) {
			  				if ($marker_start < 0) $marker_start = $i + strlen($marker_hex);
			  				else $marker_end = $i;
			  				$i += strlen($marker_hex);
			  			}
			  		}
			  		if ($marker_start < 0)  {
			  			$marker_error = "Cannot find start marker, whole file used.";
			  		} else if ($marker_end < 0)  {
			  			$marker_error = "Cannot find end marker, whole file used.";
					} else {
				  		$input_data = substr($input_data, $marker_start, $marker_end - $marker_start);
					}
				}
		  	}
		}
		// Check input_data:
		$match = preg_grep($input_data_format, array($input_data, ""));
		$input_data = substr($match[0], 0, $max_input_data_length*2);
?>
			<DIV class="layer2">
				<DIV class="header">File upload successfull!</DIV>
				<DIV class="note">
					You have uploaded &quot;<?php echo htmlentities($filename); ?>&quot;, which contains <?php echo htmlentities($filesize); ?> bytes.
				</DIV><?php
		if ($filesize > $max_input_data_length) { ?>
				<DIV class="error">
					This is more then the maximum of <?php echo $max_input_data_length; ?> bytes; only the first <?php echo $max_input_data_length; ?> bytes will be used.
				</DIV><?php
		} ?>
			    <INPUT type="hidden" name="filename" value="<?php echo htmlentities($filename); ?>">
			    <INPUT type="hidden" name="filesize" value="<?php echo htmlentities($filesize); ?>">
			    <INPUT type="hidden" name="input_data" value="<?php echo htmlentities($input_data); ?>">
				<DIV class="body">
					<?php echo htmlentities(preg_replace("/([0-9A-F]{2})/i", "$1 ", $input_data)); ?>
				</DIV>
			</DIV>
			<DIV class="layer2">
				<DIV class="header">Encoded data:</DIV><?php
		if ($marker_error) { ?>
					<DIV class="note"><?php echo $marker_error; ?></DIV><?php
		} ?>
				</DIV>
			</DIV><?php
	} else { ?>
		//---------------------------------------------------------------------
		// THE USER HAD NOT YET UPLOADED A FILE, DISPLAY THE ENTRY PAGE
			<DIV class="layer2">
				<DIV class="header">Choose a file to encode:</DIV><?php
		// IF THE USER HAS NOT UPLOADED A FILE BUT DID PRESS ENCODE, DISPLAY AN ERROR
		if ($_POST) { ?>
				<DIV class="error">You forgot to upload a file that you want to have encoded.</DIV><?php
		} ?>
				<DIV class="body">
				    <INPUT type="hidden" name="MAX_FILE_SIZE" value="<?php echo $max_input_data_length; ?>">
			    	<INPUT type="file" name="uploadfile" class="input_button">
			    	(Maximum file size is <?php echo $max_input_data_length; ?> bytes)
				</DIV>
			</DIV>
			<DIV class="layer2">
				<DIV class="header">Choose encoding options:</DIV>
				<DIV class="body"><?php
		$encoding = 5;
		if ($_POST) { $encoding = intval($_POST['encoding']); }
		if ($encoding < 0 || $encoding > 5) {
			$encoding = 5; ?>
					<DIV class="error">
						You have specified an incorrect encoding option &quot;<?php echo htmlentities($_POST['encoding']); ?>&quot;, defaulting to UTF-16.
					</DIV><?php
		} ?>
					&nbsp;&nbsp;&nbsp;C Chars: <INPUT type="radio" value="1" id="tag_encoding_c_chars" name="encoding"<?php echo ($encoding == 1 : " checked" : ""); ?>> "\x41\x41\x43\x44..."<BR>
					Hex values: <INPUT type="radio" value="2" id="tag_encoding_hex" name="encoding"<?php echo ($encoding == 2 : " checked" : ""); ?>> "0x41, 0x41, 0x43, 0x44..."<BR>
					&nbsp;&nbsp;Entities: <INPUT type="radio" value="3" id="tag_encoding_entitites" name="encoding"<?php echo ($encoding == 3 : " checked" : ""); ?>> "&amp;#65;&amp;#66;&amp;#67;&amp;#68;..."<BR>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;UTF-8: <INPUT type="radio" value="4" id="tag_encoding_utf8" name="encoding"<?php echo ($encoding == 4 : " checked" : ""); ?>> "%41%41%43%44..."<BR>
					&nbsp;&nbsp;&nbsp;&nbsp;UTF-16: <INPUT type="radio" value="5" id="tag_encoding_utf16" name="encoding"<?php echo ($encoding == 5 : " checked" : ""); ?>> "%u4241%u4443..." (Pad byte: <INPUT id="tag_padbyte" type="text" class="input_small" size="2" value="90">)<BR>
				</DIV>
			</DIV>
			<DIV class="layer2">
				<DIV class="header">Choose additional options:</DIV>
				<DIV class="body">
					<TABLE style="width:100%;"><TR><TD><NOBR>
						<INPUT type="checkbox" id="tag_use_marker" name="use_marker"<?php echo ($use_marker ? " checked" : ""); ?>>Use marker to wrap actual data:
					</NOBR></TD><TD style="width:100%;">
						<INPUT type="text" id="tag_marker" name="marker" class="input" value="<?php echo htmlentities($marker); ?>">
					</TD></TR></TABLE>
					<TABLE style="width:100%;"><TR><TD><NOBR>
						<INPUT type="checkbox" id="tag_use_badbytes" name="use_badbytes"<?php echo ($use_badbytes ? " checked" : ""); ?>>Check the code for the follwoing "bad" bytes:
					</NOBR></TD><TD style="width:100%;">
						<INPUT type="text" id="tag_badbytes" name="badbytes" class="input" value="<?php echo htmlentities($badbytes); ?>">
					</TD></TR></TABLE>
				</DIV>
			</DIV>
			<DIV class="right_align"><INPUT type="submit" value="Execute >>" class="layer2_button"></DIV><?php
} ?>
		</DIV>
	</FORM></BODY>
	<SCRIPT>
		function initialize() {
			sInternal = "<?php echo $sInternal; ?>"; bUnicode = true;
			oTagInput = document.getElementById("tag_input");
			oTagStep1 = document.getElementById("tag_step1");
			oTagStep2 = document.getElementById("tag_step2");
			oTagStep3 = document.getElementById("tag_step3");
			oTagStep4 = document.getElementById("tag_step4");
			oTagStep5 = document.getElementById("tag_step5");
			oTagInternal = document.getElementById("tag_internal");
			oTagInternalStatus = document.getElementById("tag_internal_status");
			oTagAsciiUnicode = document.getElementById("tag_ascii_unicode");
			oTagOutput = document.getElementById("tag_output");
			oTagPadbyte = document.getElementById("tag_padbyte");
			oTagUseMarker = document.getElementById("tag_use_marker");
			oTagMarker = document.getElementById("tag_marker");
		}

		function do_step1() {
			if (oTagInput.value == "") {
				for (var i in document.all) {
					if (document.all[i].input_validation) {
						document.all[i].disabled = true;
					}
				}
			} else {
				oTagStep2.style.background = "#E0E0E0";
				for (var i in document.all) {
					if (document.all[i].input_validation) {
						if (document.all[i].input_validation == "true") {
							document.all[i].disabled = false;
						} else {
							check = new RegExp(document.all[i].input_validation, "i");
							result = oTagInput.value.match(check);
							document.all[i].disabled = !(result && result[0]);
						}
					}
				}
			}
		}
		function decode(string) {
			var result8 = ""; var result16 = "";
			bUnicode = false;
			for (var i = 0; i < string.length; i++) {
				lowbyte = hexadecimal(string.charCodeAt(i) & 0xFF);
				highbyte = hexadecimal((string.charCodeAt(i) >> 8) & 0xFF);
				result8 += lowbyte + " ";
				result16 += lowbyte + highbyte + " ";
				bUnicode |= (highbyte != "00");
			}
			if (bUnicode) {
				oTagInternalStatus.innerText = "Note: Input contains UNICODE characters, each TWO bytes represent ONE character.";
				return result16;
			} else {
				oTagInternalStatus.innerText = "Note: Input contains ASCII characters only, each byte represents ONE character.";
				return result8;
			}
		}
		function do_step2(string, bytes) {
			oTagInternal.innerText = string;
			oTagInternalStatus.style.background = "#F0F0F0";
			switch (bytes) {
				case 1:
					bUnicode = false;
					oTagInternalStatus.innerText = "Note: Characters have been decoded from ASCII, each byte represents ONE character.";
					break;
				case 2:
					bUnicode = true;
					oTagInternalStatus.innerText = "Note: Characters have been decoded from UNICODE, each TWO bytes represent ONE character.";
					break;
			}
			sInternal = string.replace(/(\s)/g, "");
			oTagAsciiUnicode.disabled = false;
			if (bUnicode) {
				oTagAsciiUnicode.innerText = "Convert to ASCII";
				oTagAsciiUnicode.onclick = to_ascii;
			} else {
				oTagAsciiUnicode.innerText = "Convert to UNICODE";
				oTagAsciiUnicode.onclick = to_unicode;
			}
			
			oTagStep3.style.background = "#E0E0E0";
			oTagStep4.style.background = "#E0E0E0";
		}
		function do_step4(string) {
			oTagStep5.style.background = "#E0E0E0";
			oTagOutput.innerText = string;
		}
		function to_ascii() {
			if (confirm("Non-ASCII characters will not be converted correctly, continue?")) {
				bUnicode = false;
				oTagInternalStatus.innerText = "Note: Characters have been converted to ASCII, each byte represents ONE character.";
				do_step2(sInternal.replace(/([0-9A-F]{2})([0-9A-F]{2})/gi, '$1 '), 0);
			}
		}
		function to_unicode() {
			bUnicode = true;
			oTagInternalStatus.innerText = "Note: Characters have been converted to UNICODE, each TWO bytes represent ONE character.";
			do_step2(sInternal.replace(/([0-9A-F]{2})/gi, '$100 '), 0);
		}
		function hexadecimal(int) {
			var hexchars = "0123456789ABCDEF";
			return hexchars.charAt((int >> 4) & 0xF) +
			       hexchars.charAt(int & 0xF);
		}
		function encode_unicode(string) {
			if (string.length % 4 != 0) string += oTagPadbyte.value;
			return string.replace(/([0-9A-F]{2})([0-9A-F]{2})/gi, "%u$2$1");
		}
		function encode_entities(string) {
			string = unescape(string.replace(/([0-9A-F]{2})/gi, "%$1"));
			result = "";
			for (var i = 0; i < string.length ; i++) {
				result += "&#" + string.charCodeAt(i) + ";";
			}
			return result;
		}
		function encode_ints(string) {
			return string.substr(0, string.length - 2).replace(/([0-9A-F]{2})/gi, "0x$1, ") +
			       string.substr(string.length - 2).replace(/([0-9A-F]{2})/gi, "0x$1");
		}
		function applyMarker(string) {
			if (!oTagUseMarker.checked) return string;
			sMarker = oTagMarker.value.replace(/\s/g, "");
			aString = string.split(sMarker);
			switch(aString.length) {
				case 0: case 1:
					alert("The marker was not found in the input data!\n\nAll bytes will be converted...");
					return string;
				case 2:
					alert("The end marker was not found in the input data!\n\nAll bytes will be converted...");
					return string;
			}
			return aString[1];
		}
	</SCRIPT>
</HTML>

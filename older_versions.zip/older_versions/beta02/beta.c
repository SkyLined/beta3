#include <stdio.h>

void usage(char* name) {
  printf("\n______________________________________________________________________________"
         "\n"
         "\n     ,sSSSs,  Beta v0.2."
         "\n    dS\"   dP  Universal shellcode encoder."
         "\n   .SP dSS\"    Copyright (C) 2003 by Berend-Jan Wever"
         "\n   dS'   Sb    <skylined@edup.tudelft.nl>"
         "\n  .SP dSSP'    Encodes shellcode to a variaty of formats."
         "\n_ iS:_________________________________________________________________________"
         "\n"
         "\nUsage: %s option"
         "\nOptions:\n"
         "\n  \"--help\"                   Display this information."
         "\n  \"string\" [chars per line]  Encode as a string for C."
         "\n                              \"\\xAA\\xBB\\xCC...\""
         "\n                              If you specify a value for \"chars per line\""
         "\n                              a new line will be put after that many"
         "\n                              characters."
         "\n  \"chars\" [chars per line]   Encode as an array of chars for C."
         "\n                              '\\xAA', '\\xBB', \\xCC', ..."
         "\n                              If you specify a value for \"chars per line\""
         "\n                              a new line will be put after that many"
         "\n                              characters."
         "\n  \"int\"  [chars per line]    Encode as an array of hex values for C."
         "\n                              0xAA, 0xBB, 0xCC, ..."
         "\n  \"utf-8\" [chars per line]   Encode using utf-8."
         "\n                              %%AA%%BB%%CC..."
         "\n  \"unicode\" [chars per line] Encode using a unicode extention to utf-8."
         "\n                              %%uBBAA%%uDDCC..."
         "\n                              If the input has an uneven number of bytes,"
         "\n                              the string is padded with a NOP (0x90)."
         "\n"
         "\nInput is read from stdin and handled according to given option, the result is"
         "\nwritten to stdout."
         "\n"
         "\n", name);
}

void encoder_per_byte(int chars_per_line, char* line_header, char* line_footer,
             char* byte_header, char* byte_footer, char* byte_separator) {
  int input=0, count=0;

  if (chars_per_line>0) printf("%s", line_header);

  while ((input = getchar()) != EOF) {
    if (count > 0) {
      printf("%s", byte_separator);
      if (chars_per_line>0 && count % chars_per_line == 0)
        printf("%s%s", line_footer, line_header);
    }

    count++;
    printf("%s%02x%s", byte_header, input, byte_footer);
  }
  if (chars_per_line>0) printf("%s", line_footer);
}

void encoder_per_word(int chars_per_line, char* line_header, char* line_footer,
             char* word_header, char* word_footer, char* word_separator) {
  int input1=0, input2=0, count=0;

  if (chars_per_line>0) printf("%s", line_header);

  while ((input1 = getchar()) != EOF) {
    input2 = getchar();
    if (input2 == EOF) {
      fprintf(stderr, "Shellcode length uneven, padding with 0x90.\n");
      input2 = 0x90;
    }
    if (count > 0) {
      printf("%s", word_separator);
      if (chars_per_line>0 && count % chars_per_line == 0)
        printf("%s%s", line_footer, line_header);
    }
    count++;
    printf("%s%02x%02x%s", word_header, input2, input1, word_footer);
  }
  if (chars_per_line>0) printf("%s", line_footer);
}

int main(int argc, char* argv[]) {
  if (argc<2) {
    usage(argv[0]);
    return -1;

  } else if (strcasecmp(argv[1], "--help")==0) { // display usage information
    usage(argv[0]);

   // output length of input
   } else if (strcasecmp(argv[1], "length")==0) {
    int count=0;
    while (getchar()!=EOF) count++;
    printf("%d", count);

   // dump "\xAA\xBB\xCC..." encoded string.
   } else if (strcasecmp(argv[1], "string")==0) {
    encoder_per_byte((argc>2 ? atoi(argv[2]) : -1),
             "  \"", "\"\n",         // line header and footer.
             "\\x", "", "");         // bytes header, footer and separator.

  // dump '\xAA', '\xBB', '\xCC', ... encoded chars
  } else if (strcasecmp(argv[1], "chars")==0) {
    encoder_per_byte((argc>2 ? atoi(argv[2]) : -1),
             "  ", "\n",             // line header and footer.
             "'\\x", "'", ", ");     // bytes header, footer and separator.

  // dump 0xAA, 0xBB, 0xCC, ... encoded bytes
  } else if (strcasecmp(argv[1], "hex")==0) {
    encoder_per_byte((argc>2 ? atoi(argv[2]) : -1),
             "  ", "\n",             // line header and footer.
             "0x", "", ", ");        // bytes header, footer and separator.

  // dump "%AA%BB%CC..." encoded string
  } else if (strcasecmp(argv[1], "utf-8")==0) {
    encoder_per_byte((argc>2 ? atoi(argv[2]) : -1),
             "  \"", "\"\n",         // line header and footer.
             "%", "", "");           // bytes header, footer and separator.

  // dump "%uBBAA%uDDCC..." encoded string
  } else if (strcasecmp(argv[1], "unicode")==0) {
    encoder_per_word((argc>2 ? atoi(argv[2]) : -1),
             "  \"", "\"\n",         // line header and footer.
             "%u", "", "");           // words header, footer and separator.

  } else { // help
    usage(argv[0]);
    return -1;

  }
  return 0;
}

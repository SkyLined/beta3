#include <stdio.h>
#include <stdlib.h>

void usage(char* name) {
  printf(
    "______________________________________________________________________________\n"
    "\n"
    "     ,sSSSs,   Beta v0.3.\n"
    "    dS\"   dP   Multi-format shellcode encoding tool.\n"
    "   .SP dSS\"    Copyright (C) 2003 by Berend-Jan Wever\n"
    "   dS'   Sb    <skylined@edup.tudelft.nl>\n"
    "  .SP dSSP'    Encodes shellcode to a variety of formats.\n"
    "_ iS:_________________________________________________________________________\n"
    "\n"
    "Usage: %s option [# characters per line]"
    "Options:\n"
    "  \"help\"                    Display this information.\n"
    "  \"length\"                  Print the length of the input.\n"
    "  \"check\"                   Check the input for 0x0, 0xA and 0xD characters.\n"
    "  \"string\"                  Encode as a string for C.\n"
    "                            \"\\xAA\\xBB\\xCC...\"\n"
    "  \"chars\"                   Encode as an array of chars for C.\n"
    "                            '\\xAA', '\\xBB', \\xCC', ...\n"
    "  \"hex\"                     Encode as an array of hex values for C.\n"
    "                            0xAA, 0xBB, 0xCC, ...\n"
    "  \"utf-8\"                     Encode using utf-8.\n"
    "                            %%AA%%BB%%CC...\n"
    "  \"unicode\"                 Encode using a unicode extention to utf-8.\n"
    "                            %%uBBAA%%uDDCC...\n"
    "                            If the input has an uneven number of bytes,\n"
    "                            the string is padded with a NOP (0x90).\n"
    "  [# chars per line]        Optional number of characters of the input to\n"
    "                            encode after which a newline character will be\n"
    "                            printed.\n"
    "\n"
    "Input is read from stdin, the result is written to stdout.\n",
    name
  );
}

void encoder_per_byte(int chars_per_line, char* line_header, char* line_footer,
             char* byte_header, char* byte_footer, char* byte_separator) {
  int input=0, count=0;

  if (chars_per_line>0) printf("%s", line_header);

  while ((input = getchar()) != EOF) {
    if (count > 0) {
      printf("%s", byte_separator);
      if (chars_per_line>0 && count % chars_per_line == 0)
        printf("%s%s", line_footer, line_header);
    }

    count++;
    printf("%s%02x%s", byte_header, input, byte_footer);
  }
  if (chars_per_line>0) printf("%s", line_footer);
}

void encoder_per_word(int chars_per_line, char* line_header, char* line_footer,
             char* word_header, char* word_footer, char* word_separator) {
  int input1=0, input2=0, count=0;

  if (chars_per_line>0) printf("%s", line_header);

  while ((input1 = getchar()) != EOF) {
    input2 = getchar();
    if (input2 == EOF) input2 = 0x90;
    if (count > 0) {
      printf("%s", word_separator);
      if (chars_per_line>0 && count % chars_per_line == 0)
        printf("%s%s", line_footer, line_header);
    }
    count++;
    printf("%s%02x%02x%s", word_header, input2, input1, word_footer);
  }
  if (chars_per_line>0) printf("%s", line_footer);
}

int main(int argc, char* argv[]) {
  int chars_per_line = (argc>2 ? atoi(argv[2]) : -1);
  int i=0, j=0;
  if (argc<2 || strcasecmp(argv[1], "help")==0) {
    // display usage information
    usage(argv[0]);
  } else if (strcasecmp(argv[1], "length")==0) {
    // output length of input
    while (getchar()!=EOF) i++;
    printf("%d\n", i);
  } else if (strcasecmp(argv[1], "check")==0) {
    // check for 0x0, 0xA and 0xD
    while ((j=getchar())!=EOF) {
      i++;
      if (j==0x0 || j==0xA || j==0xD)
        printf("Character %d is 0x%02x!\n", i, j);
    }
  } else if (strcasecmp(argv[1], "string")==0) {
    // dump "\xAA\xBB\xCC..." encoded string.
    encoder_per_byte(chars_per_line, "  \"", "\"", "\\x", "", "");
  } else if (strcasecmp(argv[1], "chars")==0) {
    // dump '\xAA', '\xBB', '\xCC', ... encoded chars
    encoder_per_byte(chars_per_line, "  ", "", "'\\x", "'", ", ");
  } else if (strcasecmp(argv[1], "hex")==0) {
    // dump 0xAA, 0xBB, 0xCC, ... encoded bytes
    encoder_per_byte(chars_per_line, "  ", "", "0x", "", ", ");
  } else if (strcasecmp(argv[1], "utf-8")==0) {
    // dump "%AA%BB%CC..." encoded string
    encoder_per_byte(chars_per_line, "  \"", "\"", "%", "", "");
  } else if (strcasecmp(argv[1], "unicode")==0) {
    // dump "%uBBAA%uDDCC..." encoded string
    encoder_per_word(chars_per_line, "  \"", "\"", "%u", "", "");
  } else {
    printf("Unknown option. Type \"%0 help\" for help.\n", argv[0]);
  }
  return 0;
}

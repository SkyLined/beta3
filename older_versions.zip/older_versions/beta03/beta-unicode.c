#include <stdio.h>
#include <stdlib.h>

/*
________________________________________________________________________________
     ,sSSSs,  Beta v0.3 utf-8.
    dS"   dP
   .SP dSS"   UTF-8 shellcode encoder.
   dS'   Sb   Copyright (C) 2003,2004 by Berend-Jan Wever
  .SP dSSP'   <skylined@edup.tudelft.nl>
_ iS:___________________________________________________________________________
*/


int main(int argc, char* argv[]) {
  int input1, input2;

  while ((input1 = getchar()) != EOF) {
    if ((input2 = getchar()) == EOF) input2 = 0x90;
    printf("%%u%02x%02x", input2, input1);
  }
  return EXIT_SUCCESS;
}

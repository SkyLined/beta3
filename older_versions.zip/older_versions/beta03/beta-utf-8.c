#include <stdio.h>
#include <stdlib.h>

/*
________________________________________________________________________________
     ,sSSSs,  Beta v0.3 utf-8.
    dS"   dP
   .SP dSS"   UTF-8 shellcode encoder.
   dS'   Sb   Copyright (C) 2003,2004 by Berend-Jan Wever
  .SP dSSP'   <skylined@edup.tudelft.nl>
_ iS:___________________________________________________________________________
*/

int main(int argc, char* argv[]) {
    char input;
    while ((input = getchar()) != EOF) {
        printf("%%%02x", input);
    }
    return EXIT_SUCCESS;
}

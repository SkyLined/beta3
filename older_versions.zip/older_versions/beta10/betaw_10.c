#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

bool[256] char_is_bad = false;

void version(void) {
    printf(
        "______________________________________________________________________________\n"
        "\n"
        "     ,sSSSs,   Beta v2.0 (w32).\n"
        "    dS\"   dP   Multi-format shellcode encoding tool.\n"
        "   .SP dSS\"    Copyright (C) 2003-2005 by Berend-Jan Wever\n"
        "   dS'   Sb    <skylined@edup.tudelft.nl>\n"
        "  .SP dSSP'    En/decodes binary data to/from a variety of formats.\n"
        "_ iS:_________________________________________________________________________\n"
        "\n"
    );
  exit(EXIT_SUCCESS);
}
void help() {
    printf(
        "Usage: BETA option [#chars]\n"
        "Beta was developed to convert raw binary shellcode into text that can be\n"
        "used in exploit source-code. It can now convert be used to convert a number\n"
        "of data formats to/from each other. Additional features include the ability\n"
        "to check the input for bad characters and count the number of bytes in the\n"
        "input\n"
        "Options:\n"
		"  --badchars[=XX[,XX[...]]] Check the input for presence of the given char-\n"
		"                            acters and report where they are found. If no\n"
		"                            characters are supplied, the input will be checked\n"
		"                            for the presence of 0x0, 0xA and 0xD. *\n"
        "  --length                  Print the length of the input.\n"
        "  --marker[=XX[,XX[...]]]   The input contains both garbage and data. The data\n"
        "                            is wrapped by the marker bytes, everything before\n"
        "                            the first set and after the last set of marker\n"
        "                            bytes will be ignored. If no marker bytes are\n"
        "                            supfiles from shellcode source: 
        "  --string                  Wrap output in quotes.\n"
        "                            \"output...\"\n"
        "  --\\x                      Encode as an array of chars for C.\n"
        "                            '\\xAA', '\\xBB', \\xCC', ...\n"
        "  --0x                      Encode as an array of hex integers values for C.\n"
        "                            0xAA, 0xBB, 0xCC, ...\n"
        "  --hex                     Encode as an array of hex values.\n"
        "                            AA BB CC ...\n"
        "  --&#                      Decimal encode as entities for HTML.\n"
        "                            &#111;&#222;&#33;...\n"
        "  --%%                       Encode using utf-8.\n"
        "                            %%AA%%BB%%CC...\n"
        "  --%%u                      Encode using utf-16.\n"
        "                            %%uBBAA%%uDDCC...\n"
        "  #chars                    Optional number of encoded characters to print\n"
        "                            after which a newline gets printed.\n"
        "  --help                    Display this help and exit\n"
        "  --version                 Output version information and exit\n"
        "\n"
		" * Characters should be encoded in hexadecimal ('A'=41, '\n'=0D, etc..)\n"
        "\n"
        "Input is read from stdin, the result is written to stdout. When encoding into\n"
        "words and the input has an uneven number of bytes, the input is padded with a\n"
        "NOP (0x90) byte.\n"
    );
  exit(EXIT_SUCCESS);
}

// used for encoding each byte by itself
void encoder_per_byte(int chars_per_line, int marker, char* line_header, char* line_footer,
    char* byte_header, char* byte_format, char* byte_footer, char* byte_separator) {
    int input=0, count=0;
	int marker_count = 0;
    // line header and footer only printed when we have a max. chars per line.
    if (chars_per_line>0) printf("%s", line_header);
    // read 1 byte input from stdin
    if (marker) {
    	while (marker_count < 3 && (input = getchar()) != EOF) {
    		if (input == 0xCC) marker_count++;
    		else marker_count = 0;
    	}
    }
    marker_count = 0;
    while ((input = getchar()) != EOF && marker_count < 3) {
	    if (marker && (input == 0xCC)) marker_count++;
		else marker_count = 0;
		
        // if we've allready printed chars we might have to print seperators
        if (count > 0) {
            // we have to seperate bytes from each other with this:
            printf("%s", byte_separator);
            // if we've allready printed enough chars on this line, end it & start a new one:
            if (chars_per_line>0 && count % chars_per_line == 0)
                printf("%s%s", line_footer, line_header);
        }
        // print the byte (with it's own header and footer) and count it.
        printf("%s", byte_header);
        printf(byte_format, input);
        printf("%s", byte_footer);
        count++;
    }
    // line header and footer only printed when we have a max. chars per line.
    if (chars_per_line>0) printf("%s", line_footer);
    printf("Total input characters: %d\n", count);
}

// used for encoding two bytes into a little endian word (AA, BB -> BBAA)
void encoder_per_word(int chars_per_line, int marker, char* line_header, char* line_footer,
                  char* word_header, char* word_format, char* word_footer, char* word_separator) {
    int input1=0, input2=0, count=0;
    // line header and footer only printed when we have a max. chars per line.
    if (chars_per_line>0) printf("%s", line_header);
    // read 1 byte input from stdin
    while ((input1 = getchar()) != EOF) {
    // read another byte input from stdin
        input2 = getchar();
        // if we've allready printed chars we might have to print seperators
        if (count > 0) {
            // we have to seperate words from each other with this:
            printf("%s", word_separator);
            // if we've allready printed enough chars on this line, end it & start a new one:
            if (chars_per_line>0 && count % chars_per_line == 0)
                printf("%s%s", line_footer, line_header);
        }
        count++;
	    // if number of input bytes=uneven pad with 0x90
        if (input2 == EOF) input2 = 0x90;
        else count++;
        // print the word (with it's own header and footer) and count the bytes.
        printf("%s%02x%02x%s", word_header, input2, input1, word_footer);
    }
    // line header and footer only printed when we have a max. chars per line.
    if (chars_per_line>0) printf("%s", line_footer);
    printf("Total input characters: %d\n", count);
}

int main(int argc, char** argv, char** envp) {
    int chars_per_line = -1;
	bool print_length = false;
	int marker_length = 0; char marker[0x10];
    int error = 0, marker = 0;
    char *line_header = "", *line_footer = "\n";
    char *byte_header = "", *byte_footer = "";
    char *byte_format = "%02x", *byte_seperator = "";
    int bytes = 1;
    for (int argn = 1; !error & argn < argc; argn++) {
		//--help ---------------------------------------------------------------
    	if (stricmp(argv[argn], "--help") == 0) {
    		help();
    		return 0;
		//--version ------------------------------------------------------------
    	} else if (stricmp(argv[argn], "--version") == 0) {
    		version();
    		return 0;
		//--length -------------------------------------------------------------
    	} else if (stricmp(argv[argn], "--length") == 0) {
    		print_length = true;
		//--badchars -----------------------------------------------------------
		} else if (stricmp(argv[argn], "--badchars") == 0) {
			char_is_bad[0x0] = true;
			char_is_bad[0xA] = true;
			char_is_bad[0xD] = true;
		//--badchars=XX,XX,... -------------------------------------------------
	    } else if (strnicmp(argv[argn], "--badchars=", 11) == 0) {
			char* xarg = argv[argn][11];
			char hex[] = '0123456789ABCDEF';
			while (strlen(xarg) > 1) {
				int decoded = 0;
				for (int i = 0; i < 2; i++) {
					decoded = (strichr(hex, xarg[i]) - hex) + (decoded << 4);
					if ((decoded & 0xFF) != decoded) {
						fprintf("Incorrect character encoding in \"--badchars=\" argument: '%c' not recognised.\n", xarg[i]);
						return -1;
					}
				}
				char_is_bad[decoded] = true;
				if (xarg[2] == ',') xarg += 3;
				else xarg += 2;
			}
			if (strlen(xarg)){
				fprintf("Additional character(s) in \"--badchars=\" argument: '%s'.\n", xarg);
				return -1;
			}
		//--marker -------------------------------------------------------------
	    } else if (stricmp(argv[argn], "--marker")==0) {
	        marker_length = 3;
	        for (int i = 0; i < marker_length; i++) marker[i] = 0xCC;
		//--marker -------------------------------------------------------------
	    } else if (stricmp(argv[argn], "--marker=")==0) {
			char* xarg = argv[argn][11];
			char hex[] = '0123456789ABCDEF';
			while (strlen(xarg) > 1) {
				int decoded = 0;
				for (int i = 0; i < 2; i++) {
					decoded = (strichr(hex, xarg[i]) - hex) + (decoded << 4);
					if ((decoded & 0xFF) != decoded) {
						fprintf("Incorrect character encoding in \"--marker=\" argument: '%c' not recognised.\n", xarg[i]);
						return -1;
					}
				}
				marker[marker_length] = decoded;
				if (xarg[2] == ',') xarg += 3;
				else xarg += 2;
				marker_length++;
			}
			if (strlen(xarg)){
				fprintf("Additional character(s) in \"--marker=\" argument: '%s'.\n", xarg);
				return -1;
			}
	    } else if (strcmp(argv[argn], "--string")==0) {
	        // wrap output in quotes;
	        line_header = "\"";
	        line_footer = "\"\n";
	    } else if (strcmp(argv[argn], "--comma")==0) {
	        // separate bytes by space;
	        byte_seperator = ", ";
	    } else if (strcmp(argv[argn], "--space")==0) {
	        // separate bytes by space;
	        byte_seperator = " ";
	    } else if (stricmp(argv[argn], "--\\x")==0) {
	    	byte_header = "\\x";
	    } else if (stricmp(argv[argn], "--0x")==0) {
	    	byte_header = "0x";
	    } else if (stricmp(argv[argn], "--&#")==0) {
	    	byte_header = "&#";
	    	byte_format = "%d";
	    	byte_footer = ";";
	    } else if (stricmp(argv[argn], "--%")==0) {
	    	byte_header = "%";
	    } else if (stricmp(argv[argn], "--%u")==0) {
	    	byte_header = "%u";
	    	bytes = 2;
	    } else if ((chars_per_line = atoi(argv[argn])) < 1) {
    		printf("Unknown argument \"%s\", use \"--help\" for help.\n", argv[argn]);
        	error = 1;
        } else {
        	printf("Characters per line: %d\n", chars_per_line);
    	}
    }
	if (!error) {
		if (bytes == 1) {
	        encoder_per_byte(chars_per_line, marker, line_header, line_footer, byte_header, byte_format, byte_footer, byte_seperator);
		} else {
	        encoder_per_byte(chars_per_line, marker, line_header, line_footer, byte_header, byte_format, byte_footer, byte_seperator);
		}
	}
    return (error ? EXIT_FAILURE : EXIT_SUCCESS);
}

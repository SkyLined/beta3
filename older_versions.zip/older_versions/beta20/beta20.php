<?php
	$maxfilesize = 1000;
	$filename = "";
	$filesize = 0;
	$filecontents = "";
	$sInternal = "";
	$TagInternal = "";
	if ($_FILES['uploadfile']['tmp_name']) {
		$filename = $_FILES['uploadfile']['name'];
		$filesize = $_FILES['uploadfile']['size'];
		$file = fopen($_FILES['uploadfile']['tmp_name'], 'r');
		$filecontents = fread($file, $maxfilesize);
		fclose($file);
		$hex = "0123456789ABCDEF";
		for ($i=0; $i < strlen($filecontents); $i++) {
	    	$char = ord($filecontents{$i});
			$char = $hex{($char >> 4) & 0xF}.$hex{$char & 0xF};
	    	$sInternal .= $char;
	    	$TagInternal .= $char." ";
	  	}
	}
?>
<HTML>
	<HEAD>
		<STYLE>
			* {
				font-family: Courier New;
				font-size: 10pt;
				vertical-align: middle;
				margin: 0px;
				padding: 0px;

			}
			BODY {
				background: #808080;
			}
			DIV {
				background: #C0C0C0;
				border: 2px outset #E0E0E0;
				margin-bottom: 6px;
				margin: 3px;
				padding: 5px;
				width: 100%;
			}
			SPAN {
				background: #F0F0F0;
				border: 1px solid #D0D0D0;
				padding: 3px;
				margin: 3px;
				width: 100%;
			}
			TABLE {
				margin: 3px;
			}
			H1 {
				background: #C0C0C0;
				border: 1px solid #808080;
				width: 100%;
				margin: 3px;
			}
			BUTTON {
				background: transparent;
				border: 2px outset #FFFFFF; 
				text-align: left;
				width: 250pt;
				height: 20pt;
			}
		</STYLE>
	</HEAD>
	<BODY onLoad="initialize()">
		<DIV id="tag_step1" style="background: #E0E0E0;"><?php
if ($filecontents) {
	if ($filesize > $maxfilesize) { ?>
			<H1>1. Check uploaded file input data:</H1>
			<SPAN style="background: #F0F0F0; border: 1px solid #D0D0D0; width:100%;">
				You have uploaded &quot;<?php echo htmlentities($filename); ?>&quot;, which contains more then <?php echo $maxfilesize; ?> bytes.<BR>
				Only the first <?php echo $maxfilesize; ?> bytes have been read.
			</SPAN><?php
	} else { ?>
			<H1>1. Check uploaded file input data:</H1>
			<SPAN style="background: #F0F0F0; border: 1px solid #D0D0D0; width:100%;">
				You have uploaded &quot;<?php echo htmlentities($filename); ?>&quot;, which contains <?php echo $filesize; ?> bytes.
			</SPAN><?php
	}
} else { ?>
			<H1>1. Enter input data:</H1>
			<TEXTAREA id="tag_input" style="background: #F0F0F0; width:100%;" rows="5"
				onkeyup="do_step1();" oncut="do_step1();" onpaste="do_step1();" onmouseenter="do_step1();" onmouseleave="do_step1();"
			></TEXTAREA>
			<H1>... or upload a file:</H1>
			<FORM enctype="multipart/form-data" action="?" method="POST">
			    <INPUT type="hidden" name="MAX_FILE_SIZE" value="<?php echo $maxfilesize; ?>">
		    	<INPUT type="file" name="uploadfile" style="margin: 0px; padding:3px; background: #F0F0F0; border: 2px inset #FFFFFF; text-align: left; height: 20pt; width: 250pt;">
    			<INPUT type="submit" value="Upload" style="margin: 0px; padding:3px; background: transparent; border: 2px outset #FFFFFF; text-align: left; height: 20pt; width: 250pt;">
			</FORM><?php
} ?>
		</DIV>
		<DIV id="tag_step2">
			<H1>2. Select input data type:</H1><?php
if ($filecontents) { ?>
			<SPAN style="background: #C0C0C0; border: 1px solid #D0D0D0; width:100%;">
				You have uploaded a file, which is considered to contain raw bytes, you can therefore skip this step.
			</SPAN><?php
} else { ?>
			<TABLE cellspacing=0 cellpadding=0><TR><TD>
				<BUTTON disabled input_validation="true"
				                 onclick="do_step2(decode(oTagInput.value), 0)">
				                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Plain: ABCD</BUTTON>
				<BUTTON disabled input_validation="^(\\x[0-9A-F]{2})*$"
				                 onclick="do_step2(oTagInput.value.replace(/\\x([0-9A-F]{2})/gi, $1), 1);">
				                 &nbsp;&nbsp;&nbsp;C chars: \x41\x42\x43</BUTTON><BR>
				<BUTTON disabled input_validation="^(\%[0-9A-F]{2})*$"
				                 onclick="do_step2(oTagInput.value.replace(/\%([0-9A-F]{2})/gi, $1), 1);">
				                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;UTF-8: %41%42%43%44</BUTTON>
				<BUTTON disabled input_validation="^((:?0x[0-9A-F]{2},?\s*)*0x[0-9A-F]{2})$"
				                 onclick="do_step2(oTagInput.value.replace(/0x([0-9A-F]{2}),?\s*/gi, $1), 1);">
				                 Hex values: 0x41, 0x42, 0x43, 0x44</BUTTON><BR>
				<BUTTON disabled input_validation="^(\%u[0-9A-F]{4})*$"
				                 onclick="do_step2(oTagInput.value.replace(/\%u([0-9A-F]{2})([0-9A-F]{2})/gi, '$2$1 '), 2);">
				                 &nbsp;&nbsp;&nbsp;&nbsp;UTF-16: %u4241%u4443</BUTTON><BR>
				<BUTTON disabled input_validation="true"
				                 onclick="do_step2(decode(unescape(oTagInput.value)), 0);">
				                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mixed: A%42%u0043D</BUTTON><BR>
			</TD></TR></TABLE><?php
} ?>
		</DIV><?php
if ($filecontents) { ?>
		<DIV id="tag_step3" style="background: #E0E0E0;"><?php
} else { ?>
		<DIV id="tag_step3"><?php
} ?>
			<H1>3. Check input bytes:</H1><?php
if ($filecontents) { ?>
			<SPAN style="background: #F0F0F0; border: 1px solid #D0D0D0; width:100%;">
				Your file contained these bytes:
			</SPAN><?php
} else { ?>
			<SPAN id="tag_internal_status" style="background: #C0C0C0; border: 1px solid #D0D0D0; width:100%;">
				Once you have entered some input data, you can check if it was converted successfully here...
			</SPAN><?php
} ?>
			<SPAN id="tag_internal" style="background: transparent; border: 2px inset #FFFFFF; width:100%;"><?php echo $TagInternal; ?></SPAN>
			<BUTTON disabled id="tag_ascii_unicode">&nbsp;&nbsp;&nbsp;&nbsp;ASCII -> UNICODE</BUTTON>
		</DIV><?php
if ($filecontents) { ?>
		<DIV id="tag_step4" style="background: #E0E0E0;"><?php
} else { ?>
		<DIV id="tag_step4"><?php
} ?>
			<H1>4. Select output data type:</H1>
			<TABLE cellspacing=0 cellpadding=0><TR><TD>
				<BUTTON onclick="do_step4(unescape(applyMarker(sInternal).replace(/([0-9A-F]{2})/gi, '%$1')));">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ASCII: ABC..</BUTTON>
				<BUTTON onclick="do_step4(encode_entities(applyMarker(sInternal)));">&nbsp;&nbsp;Entities: &amp;#65;&amp;#66;&amp;#67;&amp;#68;</BUTTON><BR>
				<BUTTON onclick="do_step4(unescape(encode_unicode(applyMarker(sInternal))));">&nbsp;&nbsp;&nbsp;UNICODE: ABC..</BUTTON>
				<BUTTON onclick="do_step4(applyMarker(sInternal).replace(/([0-9A-F]{2})/gi, '\\x$1'));">&nbsp;&nbsp;&nbsp;C chars: \x41\x42\x43</BUTTON><BR>
				<BUTTON onclick="do_step4(encode_ints(applyMarker(sInternal)));">Hex values: 0x41, 0x42, 0x43, 0x44</BUTTON>
				<BUTTON onclick="do_step4(applyMarker(sInternal).replace(/([0-9A-F]{2})/gi, '%$1'));">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;UTF-8: %41%42%43%44</BUTTON><BR>
				<BUTTON onclick="do_step4(encode_unicode(applyMarker(sInternal)));">&nbsp;&nbsp;&nbsp;&nbsp;UTF-16: %u4241%u4443</BUTTON>
					Pad byte: <INPUT id="tag_padbyte" type="text" size="2" value="90"><BR>
			</TD></TR></TABLE>
			<HR>
			<SPAN style="width:250pt;margin:0px;background:transparent;"><INPUT type="checkbox" id="tag_use_marker">Use marker to wrap actual data:
			</SPAN><INPUT id="tag_marker" type="text" style="width:250pt; height:20pt;" value="CC CC CC"><BR>
		</DIV>
		<DIV id="tag_step5">
			<H1>5. Output:</H1>
			<SPAN id="tag_output" style="background: #E0E0E0; border: 2px inset #FFFFFF; width:100%;"></SPAN>
		</DIV>
	</BODY>
	<SCRIPT>
		function initialize() {
			sInternal = "<?php echo $sInternal; ?>"; bUnicode = true;
			oTagInput = document.getElementById("tag_input");
			oTagStep1 = document.getElementById("tag_step1");
			oTagStep2 = document.getElementById("tag_step2");
			oTagStep3 = document.getElementById("tag_step3");
			oTagStep4 = document.getElementById("tag_step4");
			oTagStep5 = document.getElementById("tag_step5");
			oTagInternal = document.getElementById("tag_internal");
			oTagInternalStatus = document.getElementById("tag_internal_status");
			oTagAsciiUnicode = document.getElementById("tag_ascii_unicode");
			oTagOutput = document.getElementById("tag_output");
			oTagPadbyte = document.getElementById("tag_padbyte");
			oTagUseMarker = document.getElementById("tag_use_marker");
			oTagMarker = document.getElementById("tag_marker");
		}

		function do_step1() {
			if (oTagInput.value == "") {
				for (var i in document.all) {
					if (document.all[i].input_validation) {
						document.all[i].disabled = true;
					}
				}
			} else {
				oTagStep2.style.background = "#E0E0E0";
				for (var i in document.all) {
					if (document.all[i].input_validation) {
						if (document.all[i].input_validation == "true") {
							document.all[i].disabled = false;
						} else {
							check = new RegExp(document.all[i].input_validation, "i");
							result = oTagInput.value.match(check);
							document.all[i].disabled = !(result && result[0]);
						}
					}
				}
			}
		}
		function decode(string) {
			var result8 = ""; var result16 = "";
			bUnicode = false;
			for (var i = 0; i < string.length; i++) {
				lowbyte = hexadecimal(string.charCodeAt(i) & 0xFF);
				highbyte = hexadecimal((string.charCodeAt(i) >> 8) & 0xFF);
				result8 += lowbyte + " ";
				result16 += lowbyte + highbyte + " ";
				bUnicode |= (highbyte != "00");
			}
			if (bUnicode) {
				oTagInternalStatus.innerText = "Note: Input contains UNICODE characters, each TWO bytes represent ONE character.";
				return result16;
			} else {
				oTagInternalStatus.innerText = "Note: Input contains ASCII characters only, each byte represents ONE character.";
				return result8;
			}
		}
		function do_step2(string, bytes) {
			oTagInternal.innerText = string;
			oTagInternalStatus.style.background = "#F0F0F0";
			switch (bytes) {
				case 1:
					bUnicode = false;
					oTagInternalStatus.innerText = "Note: Characters have been decoded from ASCII, each byte represents ONE character.";
					break;
				case 2:
					bUnicode = true;
					oTagInternalStatus.innerText = "Note: Characters have been decoded from UNICODE, each TWO bytes represent ONE character.";
					break;
			}
			sInternal = string.replace(/(\s)/g, "");
			oTagAsciiUnicode.disabled = false;
			if (bUnicode) {
				oTagAsciiUnicode.innerText = "Convert to ASCII";
				oTagAsciiUnicode.onclick = to_ascii;
			} else {
				oTagAsciiUnicode.innerText = "Convert to UNICODE";
				oTagAsciiUnicode.onclick = to_unicode;
			}
			
			oTagStep3.style.background = "#E0E0E0";
			oTagStep4.style.background = "#E0E0E0";
		}
		function do_step4(string) {
			oTagStep5.style.background = "#E0E0E0";
			oTagOutput.innerText = string;
		}
		function to_ascii() {
			if (confirm("Non-ASCII characters will not be converted correctly, continue?")) {
				bUnicode = false;
				oTagInternalStatus.innerText = "Note: Characters have been converted to ASCII, each byte represents ONE character.";
				do_step2(sInternal.replace(/([0-9A-F]{2})([0-9A-F]{2})/gi, '$1 '), 0);
			}
		}
		function to_unicode() {
			bUnicode = true;
			oTagInternalStatus.innerText = "Note: Characters have been converted to UNICODE, each TWO bytes represent ONE character.";
			do_step2(sInternal.replace(/([0-9A-F]{2})/gi, '$100 '), 0);
		}
		function hexadecimal(int) {
			var hexchars = "0123456789ABCDEF";
			return hexchars.charAt((int >> 4) & 0xF) +
			       hexchars.charAt(int & 0xF);
		}
		function encode_unicode(string) {
			if (string.length % 4 != 0) string += oTagPadbyte.value;
			return string.replace(/([0-9A-F]{2})([0-9A-F]{2})/gi, "%u$2$1");
		}
		function encode_entities(string) {
			string = unescape(string.replace(/([0-9A-F]{2})/gi, "%$1"));
			result = "";
			for (var i = 0; i < string.length ; i++) {
				result += "&#" + string.charCodeAt(i) + ";";
			}
			return result;
		}
		function encode_ints(string) {
			return string.substr(0, string.length - 2).replace(/([0-9A-F]{2})/gi, "0x$1, ") +
			       string.substr(string.length - 2).replace(/([0-9A-F]{2})/gi, "0x$1");
		}
		function applyMarker(string) {
			if (!oTagUseMarker.checked) return string;
			sMarker = oTagMarker.value.replace(/\s/g, "");
			aString = string.split(sMarker);
			switch(aString.length) {
				case 0: case 1:
					alert("The marker was not found in the input data!\n\nAll bytes will be converted...");
					return string;
				case 2:
					alert("The end marker was not found in the input data!\n\nAll bytes will be converted...");
					return string;
			}
			return aString[1];
		}
	</SCRIPT>
</HTML>
